# Restraint defaults: 9 October reference versus current Run path

Scope: enriched XML only, REST/default axis/stiffness/friction/gap, Datum attachment and InputXML TYPE mutation. No production implementation or release changes.

Reference: `57710dd744669a9dc1d4dbdd103d78f9f2928bce` (9 October 2026), supplied REF-STATE-agent/xml-cii-node140-gap-benchmark-rca branch. Current: `25db94769994751bb0fb6e6d83a578efd9ac8162` (28 October 2026).

## Reproduced difference

The EF-05 source exists with identical Git blob `caf814c906e4155dcf388ac7ea822aeafec76780` in both trees. The locally consumed source was restored to its exact original CRLF bytes and its Git blob verified before final generation. Both versions received their shipped standalone support defaults, with no staged JSON or master inputs attached. EF-05 exposes Datum/default behavior that the supplied SYS-0010 source does not: SYS-0010 already has 20 complete +Y restraints and gives the same core restraint result in both revisions.

| Executed enrichment entry | Restraints | Type | Zero stiffness | Datum nodes with restraint |
|---|---:|---|---:|---:|
| 9 Oct full standalone fallback chain | 173 | +Y | 0 | 73/73 |
| Current full legacy fallback chain, control | 173 | +Y | 0 | 73/73 |
| Current direct engine Python enrichment snippet | 119 | Z | 119 | 55/73 |

The old full chain replaced 94 zero-information LIM placeholders and added 79 missing REST restraints. All 173 final REST rows have stiffness 1751270000000, gap 0, friction 0.3 and direction cosines (0,1,0). The current full fallback control still performs those operations. The direct engine enrichment leaves 18 Datum nodes without restraints and retains the source Z/zero-stiffness rows. See `datum-comparison.csv` for every Datum owner and unchanged source coordinate.

Example: `PS-14167/DATUM`, node 50 in branch `/ASIM-1836-8"-P8810021-31441C4-PP/B4`, position `459657.72 -1481227.40 101259.55`: old and current legacy fallback produce +Y/1751270000000; current direct enriched XML has no restraint. Node number is recorded in the XML; the CSV keys by branch/name/position to avoid unrelated renumbering claims.

## First missing boundary

The fallback code is present. The current governed native candidate entry `runXml229NativeCiiMassCandidate` passes independently owned original XML directly to `runXmlCii2019StandaloneEngineJob` with outputMode=cii-only. It does not invoke the workflow API's `enrichStandaloneXmlForRun` wrapper chain.

The old/full workflow API installs `xml-cii-standalone-run-parity-mds-restraints.js`, including staged REST annotation, ATTA default REST/placeholder closure and MDS co-located support closure. Current direct Python enrichment calls `_maybe_enrich_from_staged_json`, `_apply_process_data_to_xml` and bend policy; this does not reproduce the browser ATTA/Datum default closure. An existing Z/zero restraint is treated as existing explicit data there. The comparison isolates a route-coverage gap, not deletion of the default constants.

This is SOURCE_INSPECTION of dispatch plus LOCAL_EXECUTION of actual enrichment functions, not an observed live browser/Final-packet CII run. Enriched XML differences alone are not an independent engineering verdict about all final CII rows. No repair is applied. Any future restoration must preserve accepted geometry and mass custody; the full legacy chain also changes geometry and must not simply be inserted after Final acceptance.

## Config probes

Executed on both revisions, using the real EF-05 core-enriched XML as input to the actual ATTA closure:

- defaultStiffness=123456 is consumed: all 173 resulting REST rows use 123456.
- defaultFriction=0 produces 0.3, due to truthy `||` fallback in the shared writer.
- defaultGap=7 produces REST gap 0. The browser REST profile/writer does not consume that modeling default in this path.
- InputXML mutation default mapping still gives TYPE 17 -> 14. Disabled mutation preserves 17. Enabled mutation with `rows: []` also preserves 17: an empty configured table is not reseeded automatically. The shipped seven rows exist in both revisions. These are pure production-function probes, not complete InputXML workflow runs.
- Current source additionally displays Tee SIF fallback 5 when the key is absent, whereas the seeded config/native fallback is 0. This is conditional SOURCE_INSPECTION, not a reproduced Owner session state.

The friction/gap probe results exist in both revisions, so these are inherited inconsistencies rather than newly dated regressions. See `config-controls.json`.

## Execution and limits

JS: actual pinned modules, Node 24.22.1, unmodified xmldom 0.9.8 DOM implementation. Python: actual current engine ENRICH_XML_SNIPPET functions under CPython 3.12.14, not Pyodide. No shim or fake XML parser was used for the final evidence. The default-restraint presence and values were independently counted with Python ElementTree.

The 16 MiB node140 staged JSON could not be retrieved as nonempty text through the GitHub connector; the binary ZIP reader also refused binary data. No claim is made for that complete staged model, real ANCI staged-REST matching, native import, private 98-component session, or CII release. ATTA implicit REST/default evidence and Datum comparison above do not require staged JSON.

`old-...enriched.xml` and `now-...direct-engine...xml` intentionally use different production entries because current governed Run bypasses the old entry. `now-...legacy-fallback-control.xml` separates code capability from dispatch coverage. Geometry node-count differences are reported in summary.json and are outside the requested repair scope.

Reproduction entry scripts are included. Supply exact old/now source checkouts as sibling folders, install xmldom 0.9.8 under vendor/xmldom09, and place source fixtures in the paths used by the scripts. `run-full.cjs` runs the full standalone wrapper; `run-core.cjs` isolates its base core; `controls.cjs` runs config probes. The direct Python sequence is the current engine ENRICH_XML_SNIPPET in `converters/xml-cii-2019-standalone/engine.js`. Artifact SHA-256 values are in provenance.json.
