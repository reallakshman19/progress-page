const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {DOMParser}=require('./vendor/xmldom09/dom-parser.js');
const {XMLSerializer}=require('./vendor/xmldom09/dom.js');
globalThis.DOMParser=DOMParser;globalThis.XMLSerializer=XMLSerializer;
const source=fs.readFileSync(process.argv[2]||path.join(__dirname,'inputs/SYS-0010.xml'),'utf8');
const out=path.join(__dirname,process.argv[3]||'results');fs.mkdirSync(out,{recursive:true});
const fields=['Type','Stiffness','Gap','Friction','DirectionCosineX','DirectionCosineY','DirectionCosineZ'];
function census(xml){const d=new DOMParser().parseFromString(xml,'application/xml');return [...d.getElementsByTagName('Node')].map(n=>({node:n.getElementsByTagName('NodeNumber')[0]?.textContent,name:n.getElementsByTagName('NodeName')[0]?.textContent,position:n.getElementsByTagName('Position')[0]?.textContent,restraints:[...n.getElementsByTagName('Restraint')].map(r=>Object.fromEntries(fields.map(f=>[f,r.getElementsByTagName(f)[0]?.textContent??null])))})).filter(n=>n.restraints.length);}
(async()=>{const summary={};for(const version of ['old','now']){
 const root=path.join(__dirname,version);fs.writeFileSync(path.join(root,'package.json'),'{"type":"module"}');
 const {DEFAULT_XML_CII_2019_SUPPORT_CONFIG:cfg}=await import(pathToFileURL(path.join(root,'tabs/xml-cii-2019-standalone/xml-cii-standalone-default-config.js')));
 const {enrichStandaloneXmlForRun}=await import(pathToFileURL(path.join(root,'tabs/xml-cii-2019-standalone/xml-cii-standalone-run-parity-mds-restraints.js')));
 const result=await enrichStandaloneXmlForRun({sourceText:source,stagedJsonText:'',supportConfigJson:JSON.stringify(cfg),options:{}}); if(result.error) throw Error(result.error); console.log(version,'parity',result.evidence?.status);
 fs.writeFileSync(path.join(out,version+'-SYS-0010-enriched.xml'),result.xmlText);fs.writeFileSync(path.join(out,version+'-diagnostics.json'),JSON.stringify(result.diagnostics,null,2));
 summary[version]={stats:result.stats,restraints:census(result.xmlText),config:cfg};console.log(version,JSON.stringify(result.stats));
 }fs.writeFileSync(path.join(out,'comparison.json'),JSON.stringify(summary,null,2));})();
