PR357 source-bound transfer evidence, 31 October2026

CONTROLLED TEST FILES ONLY. These XML/CII files are not the Owner BM2 model.
Source physical weight0 was unresolved; the test packet deliberately supplied Final12.5kg. A separate regression confirms controlled Final0 stays0. No Owner decision was accepted/changed. Native release authorization remains false.

source.xml and staged.json are synthetic, fully disclosed inputs. finalized.xml is the pre-Final Worker snapshot. enriched.xml is the actual native consumed XML, including bound12.5kg. output.CII is the actual5-element CII. GUIDE8/gap6, LINESTOP9/gap8, REST14/gap7/friction0,stiffness123456 were read from emitted bytes. This establishes transfer behavior, not engineering approval.

BM2 evidence is in summary.json: original public source ref26032 uses bodyOD60.3/DN50 and retains endpointOD26.7/DN20;15kg100%proposal remains review-only. Actual native785elements/139owners/78restraint assignments. Original Firstpass source replay passes but its later physical-owner guard holds on both candidate and exact-main binder/runtime control. No CII release claimed for Firstpass.

Run from engineering repo: TMPDIR=<existing folder> node --test tests/xml229-json-restraint-body-transfer.test.mjs
PR: https://github.com/reallakshman19/3D_Converters/pull/357
